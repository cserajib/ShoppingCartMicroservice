import React from 'react';
class OrderComponent extends React.Component{

    constructor(props){
        super(props);
    }
    render(){
    return(
     <div>
         <h1>Order Details</h1>
   <table class="table table-striped">
   <thead>
   <tr>
   <th scope="col">Order Id#</th>
   <th scope="col">Order Description</th>
   <th scope="col">Order Amount</th>
    </tr>
    </thead>
  
    <tbody>
   {this.props.orders.map(

       (order)=>(
           <tr key={order.orderId}>
            <td>{order.orderId}</td>
            <td>{order.orderDesc}</td>
            <td>{order.orderAmount}</td>
            </tr>
       )
   )}
</tbody>
    </table>
    </div>

     );
}
}
export default OrderComponent;