import React from "react";
import {useState,useEffect} from "react";
import { getItems } from './GetItems.js';
import axios from 'axios';
/*
 window.items = [
  {
    id: 1,
    name: "overwatch",
    price: 20,
  },
  {
    id: 2,
    name: "minecraft",
    price: 32,
  },
  {
    id: 3,
    name: "fortnite",
    price: 51,
  },
];
*/

  const PlaceOrderComponent = () => {

    const [items, setItems] = useState([]);

    useEffect(() => {
      let mounted = true;
      getItems()
        .then(items => {
          if(mounted) {
            setItems(items)
          }
        })
      return () => mounted = false;
    }, [])


  const [cart, setCart] = React.useState([]);
  const cartTotal = cart.reduce((total, { itemPrice = 0 }) => total + Number(itemPrice), 0);

  const addToCart = (item) => setCart((currentCart) => [...currentCart, item]);

  const removeFromCart = (item) => {
    setCart((currentCart) => {
      const indexOfItemToRemove = currentCart.findIndex((cartItem) => cartItem.itemId === item.itemId);

      if (indexOfItemToRemove === -1) {
        return currentCart;
      }

      return [
        ...currentCart.slice(0, indexOfItemToRemove),
        ...currentCart.slice(indexOfItemToRemove + 1),
      ];
    });
  };

  const amountOfItems = (id) => cart.filter((item) => item.itemId === id).length;

  const listItemsToBuy = () => items.map((item) => (
      <tr key={item.itemId}>
     <td> {item.itemName}</td>
     <td>{item.itemPrice}</td>
      <td><button type="submit" onClick={() => addToCart(item)}>Add</button></td>
    </tr>
  ));

  const listItemsInCart = () => items.map((item) => (
    <tr key={item.id}>
        <td>{amountOfItems(item.itemId)}</td>
        <td> {amountOfItems(item.itemId)} x ${item.itemPrice}</td>
       <td>{item.itemName}</td>
       <td><button type="submit" onClick={() => removeFromCart(item)}>Remove</button></td>
      </tr>
  ));

  const sendOrder=(total)=>{
    axios(
        {
            method:'POST',
            url:'http://localhost:8083/uiApi/customerorder',
            data:{
              customers:{
                custId:10051,
              },
              orders:{
        orderId:'ODR'+10051+Math.random().toString(36).substring(1),
        orderDesc:"HOUSEHOLD",
        orderAmount:total,
        custId:10051
       }
          }
        }
    ).then(response=>{document.getElementById("p1").innerHTML=response.data;}).catch(console.log);
    
  }
  return (
    <div>
  <p class="font-weight-lighter">BUY PRODUCT</p>
      <table class="table table-striped">
          <thead>
              <th scope="col">Produce Name</th>
              <th scope="col">Product Price</th>
              <th scope="col">Add to Cart</th>
          </thead>
          {listItemsToBuy()}</table>
          <hr/>
          <br></br>
          <p class="font-weight-light">Your Shopping Cart</p>      
          <table class=".table-condensed">
          <thead>
              <th>Quanity</th>
              <th>Quanity X price</th>
              <th>Product Name</th>
               </thead>
      {listItemsInCart()}</table>
      <br></br>
      <div>Total: ${cartTotal}</div>
      <br></br>
      <div>
        <button onClick={() => setCart([])}>Clear</button>
        <button onClick={()=>  sendOrder(cartTotal)}>Place Order</button>
      </div>
      <br></br><br></br>
      <div>
      <p id="p1"></p>
      </div>
    </div>
    
  );
};

export default PlaceOrderComponent;
