import React from 'react';
import CustomerOrderFormComponent from './CustomerOrderFormComponent';
import PlaceOrderComponent from './PlaceOrderComponent';

import {
    BrowserRouter,
    Switch,
    Route,
    Link
} from 'react-router-dom';

class MainComponent extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
     return(
     <BrowserRouter>
    
  <div>
   <ul>
    <li>
       <Link to="/customerorder">Search Customer Orders</Link>
   </li>
    <li>
       <Link to="/placeorder">Place new order</Link>
   </li>
    </ul>
    </div>
    <Switch>
  <Route path="/customerorder">
  <CustomerOrderFormComponent/>
  </Route>
    <Route path="/placeorder">
  <PlaceOrderComponent/>
  </Route>
 </Switch>
     </BrowserRouter>
     )
    }

}
export default MainComponent;