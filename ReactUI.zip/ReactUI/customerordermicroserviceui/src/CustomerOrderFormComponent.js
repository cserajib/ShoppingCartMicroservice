import React from 'react';
import CustomerOrderRootComponent from './CustomerOrderRootComponent';
class CustomerOrderFormComponent extends React.Component{

constructor(props){
    super(props);
    this.state={
    custId:0,
    submitted:false
    }
}

getCustId=(event)=>{
console.log(event.target.value);
this.setState({custId:event.target.value});
console.log(this.state.custId);
}
changeFlag=(event)=>{
event.preventDefault();
this.setState({submitted:true})

}
render(){
    let displayComponent;
    if(this.state.submitted){
    displayComponent=<CustomerOrderRootComponent custId={this.state.custId}/>;
}
    return(
        <div>
            <form>
            Cust Id:<input type="text" name="custId" value={this.state.custId} onChange={this.getCustId}/>
            <button onClick={this.changeFlag}>Search</button>   
            </form>
            {displayComponent}
            </div>
    );
}
}
export default CustomerOrderFormComponent;