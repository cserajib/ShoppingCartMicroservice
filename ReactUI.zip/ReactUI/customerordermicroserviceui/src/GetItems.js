export function getItems() {
    return fetch('http://localhost:8083/uiApi/items')
      .then(data => data.json())
  }