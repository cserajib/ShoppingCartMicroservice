import React from 'react';
import axios from 'axios';
import CustomerComponent from './CustomerComponent';
import OrderComponent from './OrderComponent';
class CustomerOrderRootComponent extends React.Component{
constructor(props){
    super(props);
    this.state={
        customer:[],
        orders:[]
    }
}
componentDidMount(){
     axios.get("http://localhost:8083/uiApi/customerorderdetails/"+this.props.custId)
     .then(response=>{
         this.setState({customer:response.data.customer});
          this.setState({orders:response.data.orders});
     }).catch(console.log);
 }

 render(){

     return(

         <div>
        <CustomerComponent customer={this.state.customer}/>
        <OrderComponent orders={this.state.orders}/>
        </div>
     );
 }

}
export default CustomerOrderRootComponent;