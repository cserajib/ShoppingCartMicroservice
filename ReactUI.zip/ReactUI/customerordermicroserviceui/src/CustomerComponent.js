import React from 'react';
class CustomerComponent extends React.Component{
constructor(props){
    super(props);
}
render(){
    return(
     <div>
         <h1>Customer Details</h1>
        <b>Customer Name:</b><p>{this.props.customer.custName}</p>
        <b>Mailing Address:</b><p>{this.props.customer.custAddress},{this.props.customer.custLocation},{this.props.customer.custPincodes}</p>
        <b>Contact Details:</b> Phone Number:{this.props.customer.custPhoneNumber},Email:{this.props.customer.custEmail}
    </div>
     );
}
}
export default CustomerComponent;